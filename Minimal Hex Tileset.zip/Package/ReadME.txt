﻿If you'd like to add your own tiles I encourage you to use Pico-8 color palette which is included in this pack.


Thank you for downloading "Minimal Hex Tileset" and I wish you best of luck in your personal and commercial projects,


Kacper "ThKaspar" Woźniak


You can contact me at:
	E-Mail: kac.wozniak@gmail.com

	Twitter: @ThKasparrr
 | twitter.com/ThKasparrr
	DeviantArt: ThKaspar
 | deviantart.com/thkaspar